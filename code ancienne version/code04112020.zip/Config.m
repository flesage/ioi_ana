%%Configuration system

DEF_VISUEL = 0;
DEF_FLUO = 0;
DEF_STIMSLAVE = 0;
DEF_SPECKLE = 1;
